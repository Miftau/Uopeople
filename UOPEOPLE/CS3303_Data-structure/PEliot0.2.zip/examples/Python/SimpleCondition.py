a=1

if a<0:
	print 'low'
elif a==1:
	print 'one'
else :
	print 'high'