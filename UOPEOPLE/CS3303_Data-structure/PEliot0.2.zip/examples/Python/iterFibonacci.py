a=1
b=0
i=0
n=5

while (i < n):
	temp=a;
	a=a+b
	b=temp
	
	i=i+1
	print a