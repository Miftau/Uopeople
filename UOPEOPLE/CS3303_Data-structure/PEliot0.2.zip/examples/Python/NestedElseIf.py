a = 34
b = 13
c = 25
d = 0
if a<b:
	if a>c:
		d=a
	else:
		if b<c:
			d=b
		else:
			d=c
		else:
			if a<c:
				d=a
			else:
				if b<c:
					d=c
				else:
					d=b