count = 3

num1=10
num2=5
num3=2

sum=num1+num2+num3
print sum/count
print sum % count