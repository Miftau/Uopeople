a=1

while a<3:
	print 'c'
	a=a+1
a=a+2
print a