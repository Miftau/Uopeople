a=1
b=2
c = 3

if (a<b and a<c):
	if (b>0 and c<0 or a>0):
		c=a*b
	if (b<0 or c<0):
		c=a-b