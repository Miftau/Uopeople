import jeliot.io.*;

public class If {
    public static void main() {

        // Your algorithm goes here.
       int a=2, b=1;
    if (a==b)
       { Output.println('x'); }
    else
       { Output.println('y'); }
    }
}
